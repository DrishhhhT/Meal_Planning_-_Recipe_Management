// HealthyMeal.java
public class HealthyMeal extends Meal {
    private boolean isLowCalorie;

    public HealthyMeal(String name, String recipe, String ingredients, boolean isLowCalorie) {
        super(name, recipe, ingredients);
        this.isLowCalorie = isLowCalorie;
    }

    public boolean isLowCalorie() {
        return isLowCalorie;
    }

    public void setLowCalorie(boolean lowCalorie) {
        isLowCalorie = lowCalorie;
    }

    // Override the abstract method for displaying meal details
    @Override
    public String displayMealDetails() {
        String calorieInfo = isLowCalorie ? "Low-Calorie" : "Regular-Calorie";
        return "Meal: " + getName() +
                "\nRecipe: " + getRecipe() +
                "\nIngredients: " + getIngredients() +
                "\nCalorie Information: " + calorieInfo;
    }
}
