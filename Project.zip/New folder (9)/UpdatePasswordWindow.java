import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

 public class UpdatePasswordWindow extends JFrame {
    private JTextField usernameField;
    private JPasswordField newPasswordField;
    private JPasswordField confirmNewPasswordField;
    private Users users;
	private ImageIcon img, icon,icon2;

    public UpdatePasswordWindow(JFrame parent, Users users) {
        // Set frame properties
        setTitle("Update Password");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(parent);
        this.users = users;
		
		img = new ImageIcon("desi.jpg");
        JLabel imgLabel = new JLabel(img);
        imgLabel.setBounds(430, 0, 1000, 800);
		
		icon = new ImageIcon("shield.png");
		JLabel picLabel = new JLabel(icon);
		picLabel.setBounds(290,170,75,88);
		picLabel.setBorder(null);
		
		
	    // Create panel
        JPanel panel = new JPanel(null); // Use null layout
        panel.setBackground(Color.BLACK);


        // Set background color to black
        getContentPane().setBackground(Color.BLACK);
	

        // Create components
        JLabel usernameLabel = new JLabel("Username:");
        JLabel newPasswordLabel = new JLabel("New Pass:");
        JLabel confirmNewPasswordLabel = new JLabel("Confirm New Pass:");
        usernameField = new JTextField();
        newPasswordField = new JPasswordField();
        confirmNewPasswordField = new JPasswordField();
        JButton updateButton = new JButton("Update");
		
		// Set title Font , color
		JLabel titleLabel = new JLabel("Create New Password");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 45));
        titleLabel.setBounds(80, 50, 700, 100);
        titleLabel.setForeground(Color.WHITE);
		
		// Add title label to the panel
        panel.add(titleLabel);

        // Set font and foreground color for labels
        Font labelFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        usernameLabel.setFont(labelFont);
        usernameLabel.setForeground(Color.WHITE);
        newPasswordLabel.setFont(labelFont);
        newPasswordLabel.setForeground(Color.WHITE);
        confirmNewPasswordLabel.setFont(labelFont);
        confirmNewPasswordLabel.setForeground(Color.WHITE);

        // Set button colors
        updateButton.setBackground(Color.ORANGE);
        updateButton.setForeground(Color.BLACK);

        // Set font and other properties for text fields
        Font textFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        usernameField.setFont(textFont);
        newPasswordField.setFont(textFont);
        confirmNewPasswordField.setFont(textFont);

        // Set bounds for components
        usernameLabel.setBounds(80, 330, 200, 34);
        usernameField.setBounds(280, 330, 200, 34);

        newPasswordLabel.setBounds(80, 390, 200, 34);
        newPasswordField.setBounds(280, 390, 200, 34);

        confirmNewPasswordLabel.setBounds(65, 450, 240, 32);
        confirmNewPasswordField.setBounds(280, 450, 200, 32);

        updateButton.setBounds(280, 530, 200, 36);
		
		Font buttonFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        updateButton.setFont(buttonFont);

        // Add components to the panel
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(newPasswordLabel);
        panel.add(newPasswordField);
        panel.add(confirmNewPasswordLabel);
        panel.add(confirmNewPasswordField);
        panel.add(updateButton);
		panel.add(picLabel);
		panel.add(imgLabel);

        // Add panel to the frame
        add(panel);

        // Add action listener for the Update button
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] newPassword = newPasswordField.getPassword();
                char[] confirmNewPassword = confirmNewPasswordField.getPassword();

                // Check if any of the required fields is empty
                if (username == null || username.trim().isEmpty() || new String(newPassword).trim().isEmpty() || new String(confirmNewPassword).trim().isEmpty()) {
                    JOptionPane.showMessageDialog(UpdatePasswordWindow.this, "Please, fill in all required information!");
                    return; // Exit the method without proceeding to update
                }

                if (Arrays.equals(newPassword, confirmNewPassword)) {
                    if (users.userExists(username)) {
                        // Update the password directly in the Users class
                        users.updatePassword(username, new String(newPassword));

                        JOptionPane.showMessageDialog(UpdatePasswordWindow.this, "Password updated. Login to continue!");

                        // Close the UpdatePasswordWindow
                        dispose();

                        // Open the LoginWindow
                        LoginWindow loginWindow = new LoginWindow(users);
                        loginWindow.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(UpdatePasswordWindow.this, "Username does not exist.");
                    }
                } else {
                    JOptionPane.showMessageDialog(UpdatePasswordWindow.this, "Passwords do not match.");
                }
            }
        });
    }
}





