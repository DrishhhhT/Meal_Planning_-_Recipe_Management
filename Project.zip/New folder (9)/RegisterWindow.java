import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

  public class RegisterWindow extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private Users users;
	private ImageIcon img, icon,icon2;

    public RegisterWindow(JFrame parent, Users users) {

        // Set frame properties
        setTitle("Register");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(parent);
        this.users = users;
		
		img = new ImageIcon("Pasta.jpg");
        JLabel imgLabel = new JLabel(img);
        imgLabel.setBounds(380, 0, 1000, 800);
        
		
		icon = new ImageIcon("account.png");
		JLabel picLabel = new JLabel(icon);
		picLabel.setBounds(260,180,100,100);
		picLabel.setBorder(null);

        // Create panel
        JPanel panel = new JPanel(null); // Use null layout
        panel.setBackground(Color.BLACK);

        // Set background color to black
        getContentPane().setBackground(Color.BLACK);

        // Set title Font, color
        JLabel titleLabel = new JLabel("Create Account");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 50));
        titleLabel.setBounds(80, 50, 400, 100);
        titleLabel.setForeground(Color.WHITE);

        // Create components
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel confirmPasswordLabel = new JLabel("Confirm Pass:");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        confirmPasswordField = new JPasswordField();
        JButton signUpButton = new JButton("Sign Up");

        // Set font and foreground color for labels
        Font labelFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        usernameLabel.setFont(labelFont);
        usernameLabel.setForeground(Color.WHITE);
        passwordLabel.setFont(labelFont);
        passwordLabel.setForeground(Color.WHITE);
        confirmPasswordLabel.setFont(labelFont);
        confirmPasswordLabel.setForeground(Color.WHITE);

        // Set button colors
        signUpButton.setBackground(Color.ORANGE);
        signUpButton.setForeground(Color.BLACK);

        // Set font and other properties for text fields
        Font textFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        usernameField.setFont(textFont);
        passwordField.setFont(textFont);
        confirmPasswordField.setFont(textFont);

        // Set bounds for components
        usernameLabel.setBounds(80, 330, 200, 34);
        usernameField.setBounds(250, 330, 200, 34);

        passwordLabel.setBounds(80, 390, 200, 34);
        passwordField.setBounds(250, 390, 200, 34);

        confirmPasswordLabel.setBounds(80, 450, 240, 34);
        confirmPasswordField.setBounds(250, 450, 200, 34);

        signUpButton.setBounds(250, 530, 200, 36);

        // Set font the button
        Font buttonFont = new Font("Comic Sans MS", Font.ITALIC, 23);
        signUpButton.setFont(buttonFont);

        // Add components to the panel
        panel.add(titleLabel);  // Add titleLabel before other components
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(confirmPasswordLabel);
        panel.add(confirmPasswordField);
        panel.add(signUpButton);
		panel.add(picLabel);
		panel.add(imgLabel);

        // Add panel to the frame
        add(panel);

        // Add action listener for the Sign Up button
        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] password = passwordField.getPassword();
                char[] confirmPassword = confirmPasswordField.getPassword();

                // Check if any of the required fields is empty
                if (username == null || username.trim().isEmpty() || new String(password).trim().isEmpty() || new String(confirmPassword).trim().isEmpty()) {
                    JOptionPane.showMessageDialog(RegisterWindow.this, "Please, fill in all required information!");
                    return; // Exit the method without proceeding to signup
                }

                if (Arrays.equals(password, confirmPassword)) {
                    if (!users.userExists(username)) {
                        User newUser = new User(username, new String(password));
                        users.addUser(newUser);

                        JOptionPane.showMessageDialog(RegisterWindow.this, "Sign Up successful!");

                        // Close the RegisterWindow after signup
                        dispose();

                        // Show the LoginWindow
                        JFrame loginWindow = new LoginWindow(users);
                        loginWindow.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(RegisterWindow.this, "Username already exists. Choose another username.");
                    }
                } else {
                    JOptionPane.showMessageDialog(RegisterWindow.this, "Passwords do not match.");
                }
            }
        });
    }

  
}

