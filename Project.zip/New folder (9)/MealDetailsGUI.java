import javax.swing.*;
import java.awt.*;


public class MealDetailsGUI extends JFrame {
	
	  //private JLabel imgLabel;
      //private ImageIcon img;

    public MealDetailsGUI(String selectedMeal) {
        setTitle("Meal Details");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(null); // Use null layout for precise positioning
        panel.setBackground(Color.BLACK);
		
		//img = new ImageIcon("Food10.jpg");
        //imgLabel = new JLabel(img);
        //imgLabel.setBounds(410, 0, 1000, 800);
       //panel.add(imgLabel);

        JLabel mealLabel = new JLabel("Meal: " + selectedMeal);
        mealLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 36));
        mealLabel.setBounds(100, 20, 560, 50);
        mealLabel.setForeground(Color.WHITE);
        panel.add(mealLabel);

        JTextArea recipeArea = new JTextArea(getRecipe(selectedMeal));
        recipeArea.setFont(new Font("Georgia", Font.ITALIC, 20));
        recipeArea.setEditable(false);
		recipeArea.setBackground(Color.BLACK);
		recipeArea.setForeground(Color.WHITE);
        JScrollPane recipeScrollPane = new JScrollPane(recipeArea);
        JLabel recipeLabel = new JLabel("Recipe:");
        recipeLabel.setBounds(100, 80, 100, 40);
        recipeLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 26));
        recipeLabel.setForeground(Color.WHITE);
        panel.add(recipeLabel);
        recipeScrollPane.setBounds(100, 120, 800, 200);
        panel.add(recipeScrollPane);

        JTextArea ingredientsArea = new JTextArea(getIngredients(selectedMeal));
        ingredientsArea.setFont(new Font("Georgia", Font.ITALIC, 20));
		ingredientsArea.setEditable(false);
		ingredientsArea.setBackground(Color.BLACK);
		ingredientsArea.setForeground(Color.WHITE);
        JScrollPane ingredientsScrollPane = new JScrollPane(ingredientsArea);
        JLabel ingredientsLabel = new JLabel("Ingredients:");
        ingredientsLabel.setBounds(100, 350, 180, 40);
        ingredientsLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 26));
        ingredientsLabel.setForeground(Color.WHITE);
        panel.add(ingredientsLabel);
        ingredientsScrollPane.setBounds(100, 390, 800, 200);
        panel.add(ingredientsScrollPane);
		
		JButton backButton = new JButton("Back");
        backButton.setBounds(280, 650, 200, 32);
		backButton.setFont(new Font("Monaco", Font.ITALIC, 23));
        backButton.setBackground(Color.BLUE);
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> goBackToMealNamesGUI());
        panel.add(backButton);
		
		JButton closeButton = new JButton("Close");
        closeButton.setBounds(500, 650, 200, 32);
		closeButton.setFont(new Font("Monaco", Font.ITALIC, 23));
        closeButton.setBackground(Color.RED);
        closeButton.setForeground(Color.WHITE);
        closeButton.addActionListener(e -> closeWindow());
        panel.add(closeButton);

        add(panel);
    }

    private String getRecipe(String meal) {
        switch (meal) {
            case "Oatmeal with Fruits":
                return " 1. Cook oats according to package instructions.\n" +
                        " 2. Top with sliced fruits (e.g., bananas, berries).\n" +
                        " 3. Optional: Add a drizzle of honey or maple syrup.";
            case "Scrambled Eggs":
                return " 1. Whisk eggs in a bowl.\n" +
                        " 2. Heat a pan over medium heat and add butter.\n" +
                        " 3. Pour whisked eggs into the pan and scramble until cooked.\n" +
                        " 4. Season with salt and pepper to taste.";
            case "Smoothie Bowl":
                return " 1. Blend your favorite fruits (e.g., berries, banana, spinach) with yogurt or milk.\n" +
                        " 2. Pour the smoothie into a bowl.\n" +
                        " 3. Top with granola, nuts, and seeds.";
            case "Pancakes":
                return " 1. Mix flour, sugar, baking powder, and salt in a bowl.\n" +
                        " 2. Add milk, eggs, and melted butter to the dry ingredients.\n" +
                        " 3. Stir until just combined.\n" +
                        " 4. Pour batter onto a hot griddle and cook until bubbles form.\n" +
                        " 5. Flip and cook until golden brown.";
            case "Avocado Toast":
                return " 1. Toast slices of bread.\n" +
                        " 2. Mash ripe avocados and spread over the toast.\n" +
                        " 3. Sprinkle with salt, pepper, and red pepper flakes.\n" +
                        " 4. Optionally, add a poached egg on top.";
            case "Greek Yogurt with Berries":
                return " 1. Spoon Greek yogurt into a bowl.\n" +
                        " 2. Top with fresh berries (e.g., blueberries, strawberries).\n" +
                        " 3. Optional: Drizzle with honey and sprinkle with granola.";
            case "Granola Parfait":
                return " 1. Layer granola, Greek yogurt, and mixed berries in a glass.\n" +
                        " 2. Repeat the layers until the glass is filled.\n" +
                        " 3. Top with a dollop of yogurt and a sprinkle of granola.";
            case "Bagel with Cream Cheese":
                return " 1. Toast a bagel until golden brown.\n" +
                        " 2. Spread cream cheese on the toasted bagel halves.\n" +
                        " 3. Optional: Add smoked salmon, capers, and fresh dill.";
            case "Breakfast Burrito":
                return " 1. Scramble eggs and cook until done.\n" +
                        " 2. Add cooked eggs, black beans, cheese, and salsa to a tortilla.\n" +
                        " 3. Roll into a burrito and enjoy!";
            case "Grilled Chicken Salad":
                return " 1. Grill chicken breasts until cooked through.\n" +
                        " 2. Chop grilled chicken and mix with salad greens.\n" +
                        " 3. Add cherry tomatoes, cucumber, and your favorite dressing.";
            case "Vegetable Wrap":
                return " 1. Sautee mixed vegetables (bell peppers, zucchini, onions) in olive oil.\n" +
                        " 2. Fill a tortilla with the sauteed vegetables.\n" +
                        " 3. Top with hummus or your favorite sauce.";
            case "Quinoa Bowl":
                return "1. Cook quinoa according to package instructions.\n" +
                        "2. Top quinoa with roasted vegetables, feta cheese, and a drizzle of balsamic glaze.";
            case "Caprese Sandwich":
                return " 1. Layer fresh mozzarella, tomato slices, and basil leaves on ciabatta bread.\n" +
                        " 2. Drizzle with balsamic glaze and add salt and pepper to taste.";
            case "Caesar Salad":
                return " 1. Toss chopped romaine lettuce with Caesar dressing.\n" +
                        " 2. Add croutons, shaved parmesan, and grilled chicken if desired.";
            case "Chicken Caesar Wrap":
                return " 1. Grill or cook chicken and slice into strips.\n" +
                        " 2. Lay out a tortilla and spread Caesar dressing on it.\n" +
                        " 3. Add sliced chicken, romaine lettuce, and grated parmesan.\n" +
                        " 4. Roll up the tortilla to form a wrap.";
            case "Mediterranean Salad":
                return " 1. Chop cucumbers, tomatoes, red onions, and olives.\n" +
                        " 2. Mix the vegetables and add feta cheese.\n" +
                        " 3. Dress with olive oil, lemon juice, salt, and pepper.";
            case "Turkey Club Sandwich":
                return " 1. Toast slices of bread.\n" +
                        " 2. Layer turkey, bacon, lettuce, and tomato between the slices.\n" +
                        " 3. Cut in half and secure with toothpicks.";
            case "Vegetarian Pizza":
                return " 1. Roll out pizza dough on a baking sheet.\n" +
                        " 2. Spread tomato sauce and sprinkle with cheese.\n" +
                        " 3. Add your favorite vegetables as toppings.";
            case "Salmon with Asparagus":
                return " 1. Season salmon fillets with salt, pepper, and lemon juice.\n" +
                        " 2. Roast in the oven with asparagus until salmon is cooked through.";
            case "Pasta Primavera":
                return " 1. Cook your favorite pasta.\n" +
                        " 2. Sautee a mix of colorful vegetables (e.g., bell peppers, cherry tomatoes, broccoli).\n" +
                        " 3. Toss the cooked pasta with the sauteed vegetables and olive oil.";
            case "Stir-Fried Tofu":
                return " 1. Press tofu to remove excess water and cut into cubes.\n" +
                        " 2. Stir-fry tofu in a pan with soy sauce, ginger, and garlic.\n" +
                        " 3. Add your favorite stir-fried vegetables.";
            case "Chicken Alfredo":
                return " 1. Cook fettuccine pasta according to package instructions.\n" +
                        " 2. In a separate pan, cook chicken in Alfredo sauce.\n" +
                        " 3. Mix pasta with the chicken Alfredo.";
            case "Mushroom Risotto":
                return " 1. Sautee mushrooms and onions in butter until softened.\n" +
                        " 2. Add Arborio rice and cook until translucent.\n" +
                        " 3. Gradually add chicken or vegetable broth, stirring until rice is creamy.";
            case "Beef Stir-Fry":
                return " 1. Slice beef into thin strips.\n" +
                        " 2. Stir-fry beef in a pan with vegetables (e.g., broccoli, bell peppers) and soy sauce.\n" +
                        " 3. Serve over rice or noodles.";
            case "Shrimp Scampi":
                return " 1. Cook linguine pasta according to package instructions.\n" +
                        " 2. Sautee shrimp in butter, garlic, and lemon juice until cooked.\n" +
                        " 3. Toss cooked pasta with shrimp mixture.";
            case "Vegetable Lasagna":
                return " 1. Layer lasagna noodles with ricotta cheese, marinara sauce, and a mix of sauteed vegetables.\n" +
                        " 2. Repeat the layers and bake until bubbly and golden.";
            case "Honey Glazed Chicken":
                return " 1. Marinate chicken in a mixture of honey, soy sauce, garlic, and ginger.\n" +
                        " 2. Bake or grill until chicken is cooked through and glaze is caramelized.";
            default:
                return " Recipe not available";
        }
    }

    private String getIngredients(String meal) {
        switch (meal) {
            case "Oatmeal with Fruits":
                return  " - Oats\n" +
                        " - Milk or water\n" +
                        " - Sliced fruits (e.g., bananas, berries)\n" +
                        " - Honey or maple syrup (optional)";
            case "Scrambled Eggs":
                return  " - Eggs\n" +
                        " - Butter\n" +
                        " - Salt and pepper to taste";
            case "Smoothie Bowl":
                return  " - Mixed berries\n" +
                        " - Banana\n" +
                        " - Spinach\n" +
                        " - Yogurt or milk\n" +
                        " - Granola, nuts, and seeds for topping";
            case "Pancakes":
                return  " - All-purpose flour\n" +
                        " - Sugar\n" +
                        " - Baking powder\n" +
                        " - Salt\n" +
                        " - Milk\n" +
                        " - Eggs\n" +
                        " - Butter";
            case "Avocado Toast":
                return  " - Bread slices\n" +
                        " - Ripe avocados\n" +
                        " - Salt\n" +
                        " - Pepper\n" +
                        " - Red pepper flakes (optional)\n" +
                        " - Poached egg (optional)";
            case "Greek Yogurt with Berries":
                return  " - Greek yogurt\n" +
                        " - Fresh berries (e.g., blueberries, strawberries)\n" +
                        " - Honey\n" +
                        " - Granola";
            case "Granola Parfait":
                return  " - Granola\n" +
                        " - Greek yogurt\n" +
                        " - Mixed berries";
            case "Bagel with Cream Cheese":
                return  " - Bagel\n" +
                        " - Cream cheese\n" +
                        " - Smoked salmon (optional)\n" +
                        " - Capers (optional)\n" +
                        " - Fresh dill (optional)";
            case "Breakfast Burrito":
                return  " - Eggs\n" +
                        " - Black beans\n" +
                        " - Cheese\n" +
                        " - Salsa\n" +
                        " - Tortilla";
            case "Grilled Chicken Salad":
                return  " - Chicken breasts\n" +
                        " - Salad greens\n" +
                        " - Cherry tomatoes\n" +
                        " - Cucumber\n" +
                        " - Salad dressing";
            case "Vegetable Wrap":
                return  " - Tortillas\n" +
                        " - Mixed vegetables (bell peppers, zucchini, onions)\n" +
                        " - Olive oil\n" +
                        " - Hummus or sauce of choice";
            case "Quinoa Bowl":
                return  " - Quinoa\n" +
                        " - Roasted vegetables\n" +
                        " - Feta cheese\n" +
                        " - Balsamic glaze";
            case "Caprese Sandwich":
                return  " - Ciabatta bread\n" +
                        " - Fresh mozzarella\n" +
                        " - Tomatoes\n" +
                        " - Basil leaves\n" +
                        " - Balsamic glaze\n" +
                        " - Salt and pepper";
            case "Caesar Salad":
                return  " - Romaine lettuce\n" +
                        " - Caesar dressing\n" +
                        " - Croutons\n" +
                        " - Shaved parmesan\n" +
                        " - Grilled chicken (optional)";
            case "Chicken Caesar Wrap":
                return  " - Chicken\n" +
                        " - Tortilla\n" +
                        " - Caesar dressing\n" +
                        " - Romaine lettuce\n" +
                        " - Parmesan cheese";
            case "Mediterranean Salad":
                return  " - Cucumbers\n" +
                        " - Tomatoes\n" +
                        " - Red onions\n" +
                        " - Olives\n" +
                        " - Feta cheese\n" +
                        " - Olive oil\n" +
                        " - Lemon juice\n" +
                        " - Salt and pepper";
            case "Turkey Club Sandwich":
                return  " - Sliced turkey\n" +
                        " - Bacon\n" +
                        " - Lettuce\n" +
                        " - Tomato\n" +
                        " - Bread\n" +
                        " - Mayonnaise";
            case "Vegetarian Pizza":
                return  " - Pizza dough\n" +
                        " - Tomato sauce\n" +
                        " - Cheese\n" +
                        " - Vegetables (e.g., bell peppers, mushrooms, onions)";
            case "Salmon with Asparagus":
                return  " - Salmon fillets\n" +
                        " - Asparagus\n" +
                        " - Salt\n" +
                        " - Pepper\n" +
                        " - Lemon juice";
            case "Pasta Primavera":
                return  " - Pasta\n" +
                        " - Bell peppers\n" +
                        " - Cherry tomatoes\n" +
                        " - Broccoli\n" +
                        " - Olive oil";
            case "Stir-Fried Tofu":
                return  " - Tofu\n" +
                        " - Soy sauce\n" +
                        " - Ginger\n" +
                        " - Garlic\n" +
                        " - Stir-fried vegetables";
            case "Chicken Alfredo":
                return  " - Fettuccine pasta\n" +
                        " - Chicken\n" +
                        " - Alfredo sauce";
            case "Mushroom Risotto":
                return  " - Arborio rice\n" +
                        " - Mushrooms\n" +
                        " - Onions\n" +
                        " - Butter\n" +
                        " - Chicken or vegetable broth";
            case "Beef Stir-Fry":
                return  " - Beef\n" +
                        " - Vegetables (e.g., broccoli, bell peppers)\n" +
                        " - Soy sauce\n" +
                        " - Rice or noodles";
            case "Shrimp Scampi":
                return  " - Linguine pasta\n" +
                        " - Shrimp\n" +
                        " - Butter\n" +
                        " - Garlic\n" +
                        " - Lemon juice";
            case "Vegetable Lasagna":
                return  " - Lasagna noodles\n" +
                        " - Ricotta cheese\n" +
                        " - Marinara sauce\n" +
                        " - Mixed vegetables\n" +
                        " - Mozzarella cheese";
            case "Honey Glazed Chicken":
                return  " - Chicken\n" +
                        " - Honey\n" +
                        " - Soy sauce\n" +
                        " - Garlic\n" +
                        " - Ginger";
            default:
                return " Ingredients not available";
        }
    }
	 private void goBackToMealNamesGUI() {
        MealNamesGUI mealNamesGUI = new MealNamesGUI("Breakfast");
        mealNamesGUI.setVisible(true);
        this.dispose(); // Close the MealDetailsGUI and go back to MealNamesGUI
    }
	 private void closeWindow() {
        this.dispose(); // Close the MealDetailsGUI
    }

}

        
