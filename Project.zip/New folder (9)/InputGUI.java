import javax.swing.*;
import java.awt.*;
import java.util.Enumeration;

public class InputGUI extends JFrame {

    private JLabel ageLabel, heightLabel, weightLabel, genderLabel, heightUnitLabel, weightUnitLabel, activityLabel,AlgLabel,BFLabel,imgLabel;;
    private JTextField ageTextField, heightTextField, weightTextField;
    private JRadioButton maleRadioButton, femaleRadioButton, othersRadioButton, sedentaryRadioButton,
            lightlyActiveRadioButton, moderatelyActiveRadioButton, veryActiveRadioButton;
    private ButtonGroup genderGroup, activityLevelGroup;
	private JCheckBox milkCheckBox, eggCheckBox, peanutCheckBox, treeNutCheckBox, soyCheckBox, wheatCheckBox, fishCheckBox, shellfishCheckBox;
    private JComboBox<String> BFComboBox;
    private JPanel panel;
	private ImageIcon img, icon;

    public InputGUI() {
        setTitle("Input Information");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
		
		img = new ImageIcon("Food3.jpg");
        imgLabel = new JLabel(img);
        imgLabel.setBounds(440, 0, 1000, 800);
        panel.add(imgLabel);
		
		icon = new ImageIcon("Test2.png");
		JLabel picLabel = new JLabel(icon);
		picLabel.setBounds(500,40,50,50);
		picLabel.setBorder(null);
		panel.add(picLabel);

        JLabel titleLabel = new JLabel("Personal Information");
        titleLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 34));
        titleLabel.setBounds(130, 30, 400, 70);
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel);

        panel.setBackground(Color.BLACK);
		
        //label for age,height,weight,gender,activity,allegies
        ageLabel = new JLabel("Age:");
		ageLabel.setFont(new Font("Monaco", Font.ITALIC, 15));
        ageLabel.setBounds(70, 140, 80, 30);
		ageLabel.setForeground(Color.WHITE);
        panel.add(ageLabel);

        heightLabel = new JLabel("Height:");
		heightLabel.setFont(new Font("Monaco", Font.ITALIC, 15));
        heightLabel.setBounds(70, 180, 80, 30);
        heightLabel.setForeground(Color.WHITE);
        panel.add(heightLabel);

        weightLabel = new JLabel("Weight:");
		weightLabel.setFont(new Font("Monaco", Font.ITALIC, 15));
        weightLabel.setBounds(70, 220, 80, 30);
		weightLabel.setForeground(Color.WHITE);
        panel.add(weightLabel);

        genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(70, 280, 80, 30);
		genderLabel.setFont(new Font("Monaco", Font.ITALIC, 15));
		genderLabel.setForeground(Color.WHITE);
        panel.add(genderLabel);

        heightUnitLabel = new JLabel("cm");
        heightUnitLabel.setBounds(240, 180, 30, 30);
		heightUnitLabel.setFont(new Font("Monaco", Font.ITALIC, 13));
		heightUnitLabel.setForeground(Color.WHITE);
        panel.add(heightUnitLabel);

        weightUnitLabel = new JLabel("kg");
        weightUnitLabel.setBounds(240, 220, 30, 30);
		weightUnitLabel.setFont(new Font("Monaco", Font.ITALIC, 13));
		weightUnitLabel.setForeground(Color.WHITE);
        panel.add(weightUnitLabel);

        activityLabel = new JLabel("Activity:");
        activityLabel.setBounds(70, 420, 80, 30);
		activityLabel.setFont(new Font("Monaco", Font.ITALIC, 15));
		activityLabel.setForeground(Color.WHITE);
        panel.add(activityLabel);
		
		AlgLabel = new JLabel("Allergies:");
        AlgLabel.setBounds(360, 140, 80, 30);
        AlgLabel.setFont(new Font("Monaco", Font.ITALIC, 15));
		AlgLabel.setForeground(Color.WHITE);
        panel.add(AlgLabel);
		
		BFLabel = new JLabel("Body Fat:");
        BFLabel.setBounds(360, 480, 80, 30);
		BFLabel.setFont(new Font("Monaco", Font.ITALIC, 15));
		BFLabel.setForeground(Color.WHITE);
        panel.add(BFLabel);

        //text fields for age, height, and weight
        ageTextField = new JTextField();
        ageTextField.setBounds(130, 140, 100, 25);
        ageTextField.setBackground(Color.ORANGE);
        ageTextField.setForeground(Color.BLACK);
        panel.add(ageTextField);

        heightTextField = new JTextField();
        heightTextField.setBounds(130, 180, 100, 25);
        heightTextField.setBackground(Color.ORANGE);
        heightTextField.setForeground(Color.BLACK);
        panel.add(heightTextField);

        weightTextField = new JTextField();
        weightTextField.setBounds(130, 220, 100, 25);
        weightTextField.setBackground(Color.ORANGE);
        weightTextField.setForeground(Color.BLACK);
        panel.add(weightTextField);

        // Gender selection
        maleRadioButton = new JRadioButton("Male");
        femaleRadioButton = new JRadioButton("Female");
        othersRadioButton = new JRadioButton("Others");
        genderGroup = new ButtonGroup();
        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);
        genderGroup.add(othersRadioButton);

        maleRadioButton.setBounds(130, 280, 80, 30);
		maleRadioButton.setFont(new Font("Monaco", Font.ITALIC, 15));
        maleRadioButton.setBackground(Color.ORANGE);
        maleRadioButton.setForeground(Color.BLACK);
        panel.add(maleRadioButton);

        femaleRadioButton.setBounds(130, 320, 80, 30);
		femaleRadioButton.setFont(new Font("Monaco", Font.ITALIC, 15));
        femaleRadioButton.setBackground(Color.ORANGE);
        femaleRadioButton.setForeground(Color.BLACK);
        panel.add(femaleRadioButton);

        othersRadioButton.setBounds(130, 360, 80, 30);
		othersRadioButton.setFont(new Font("Monaco", Font.ITALIC, 15));
        othersRadioButton.setBackground(Color.ORANGE);
        othersRadioButton.setForeground(Color.BLACK);
        panel.add(othersRadioButton);

        // Activity level selection
        sedentaryRadioButton = new JRadioButton("Sedentary");
        lightlyActiveRadioButton = new JRadioButton("Lightly Active");
        moderatelyActiveRadioButton = new JRadioButton("Moderately Active");
        veryActiveRadioButton = new JRadioButton("Very Active");

        activityLevelGroup = new ButtonGroup();
        activityLevelGroup.add(sedentaryRadioButton);
        activityLevelGroup.add(lightlyActiveRadioButton);
        activityLevelGroup.add(moderatelyActiveRadioButton);
        activityLevelGroup.add(veryActiveRadioButton);

        sedentaryRadioButton.setBounds(130, 420, 170, 30);
		sedentaryRadioButton.setFont(new Font("Monaco", Font.ITALIC, 15));
        sedentaryRadioButton.setBackground(Color.ORANGE);
        sedentaryRadioButton.setForeground(Color.BLACK);
        panel.add(sedentaryRadioButton);

        lightlyActiveRadioButton.setBounds(130, 460, 170, 30);
		lightlyActiveRadioButton.setFont(new Font("Monaco", Font.ITALIC, 15));
        lightlyActiveRadioButton.setBackground(Color.ORANGE);
        lightlyActiveRadioButton.setForeground(Color.BLACK);
        panel.add(lightlyActiveRadioButton);

        moderatelyActiveRadioButton.setBounds(130, 500, 170, 30);
		moderatelyActiveRadioButton.setFont(new Font("Monaco", Font.ITALIC, 15));
        moderatelyActiveRadioButton.setBackground(Color.ORANGE);
        moderatelyActiveRadioButton.setForeground(Color.BLACK);
        panel.add(moderatelyActiveRadioButton);

        veryActiveRadioButton.setBounds(130, 540, 170, 30);
		veryActiveRadioButton.setFont(new Font("Monaco", Font.ITALIC, 15));
        veryActiveRadioButton.setBackground(Color.ORANGE);
        veryActiveRadioButton.setForeground(Color.BLACK);
        panel.add(veryActiveRadioButton);
		
		//body fat level
		String[] BFLevels = {"Low", "Medium", "High"};
        BFComboBox = new JComboBox<>(BFLevels);
        BFComboBox.setBounds(450, 480, 90, 30);
		BFComboBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        BFComboBox.setBackground(Color.ORANGE);
        BFComboBox.setForeground(Color.BLACK);
        panel.add(BFComboBox);
		
		//checkboxes for food allergies
        milkCheckBox = new JCheckBox("Milk");
        milkCheckBox.setBounds(450, 140, 90, 30);
		milkCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        milkCheckBox.setBackground(Color.ORANGE);
        milkCheckBox.setForeground(Color.BLACK);
        panel.add(milkCheckBox);

        eggCheckBox = new JCheckBox("Egg");
        eggCheckBox.setBounds(450, 180, 90, 30);
		eggCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        eggCheckBox.setBackground(Color.ORANGE);
        eggCheckBox.setForeground(Color.BLACK);
        panel.add(eggCheckBox);

        peanutCheckBox = new JCheckBox("Peanut");
        peanutCheckBox.setBounds(450, 220, 90, 30);
		peanutCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        peanutCheckBox.setBackground(Color.ORANGE);
        peanutCheckBox.setForeground(Color.BLACK);
        panel.add(peanutCheckBox);

        treeNutCheckBox = new JCheckBox("Tree Nut");
        treeNutCheckBox.setBounds(450, 260, 90, 30);
		treeNutCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        treeNutCheckBox.setBackground(Color.ORANGE);
        treeNutCheckBox.setForeground(Color.BLACK);
        panel.add(treeNutCheckBox);

        soyCheckBox = new JCheckBox("Soy");
        soyCheckBox.setBounds(450, 300, 90, 30);
		soyCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        soyCheckBox.setBackground(Color.ORANGE);
        soyCheckBox.setForeground(Color.BLACK);
        panel.add(soyCheckBox);

        wheatCheckBox = new JCheckBox("Wheat");
        wheatCheckBox.setBounds(450, 340, 90, 30);
		wheatCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        wheatCheckBox.setBackground(Color.ORANGE);
        wheatCheckBox.setForeground(Color.BLACK);
        panel.add(wheatCheckBox);

        fishCheckBox = new JCheckBox("Fish");
        fishCheckBox.setBounds(450, 380, 90, 30);
		fishCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        fishCheckBox.setBackground(Color.ORANGE);
        fishCheckBox.setForeground(Color.BLACK);
        panel.add(fishCheckBox);

        shellfishCheckBox = new JCheckBox("Shellfish");
        shellfishCheckBox.setBounds(450, 420, 90, 30);
		shellfishCheckBox.setFont(new Font("Monaco", Font.ITALIC, 15));
        shellfishCheckBox.setBackground(Color.ORANGE);
        shellfishCheckBox.setForeground(Color.BLACK);
        panel.add(shellfishCheckBox);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> calculateAndShowCalories());
        submitButton.setBounds(170, 640, 200, 40);
		submitButton.setFont(new Font("Monaco", Font.ITALIC, 25));
		submitButton.setBackground(Color.BLUE);
		submitButton.setForeground(Color.WHITE);
        panel.add(submitButton);
		
		JButton skipButton = new JButton("Skip");
        skipButton.addActionListener(e -> skipToMealsGUI());
        skipButton.setBounds(400, 640, 100, 40);
        skipButton.setFont(new Font("Monaco", Font.ITALIC, 25));
        skipButton.setBackground(Color.GRAY);
        skipButton.setForeground(Color.WHITE);
        panel.add(skipButton);

        add(panel);
        //setVisible(true);
    }
	
	private void skipToMealsGUI() {
        MealsGUI mealsGUI = new MealsGUI();
        mealsGUI.setVisible(true);

        this.dispose(); // Close the input GUI after skipping
    }

    private void calculateAndShowCalories() {
        int age = Integer.parseInt(ageTextField.getText());
        double height = Double.parseDouble(heightTextField.getText());
        double weight = Double.parseDouble(weightTextField.getText());

        String gender = getSelectedGender();
        String activityLevel = getSelectedActivityLevel();

        Person person;

        if ("Male".equals(gender)) {
            person = new MaleAthlete(age, height, weight, "Running", activityLevel);
        } else {
            person = new FemaleAthlete(age, height, weight, "Running", activityLevel);
        }

        double dailyCalories = person.calculateDailyCalories();
        double carbohydrate = person.calculateCarbohydrate();
        double protein = person.calculateProtein();
        double fat = person.calculateFat();

        CaloriesGUI caloriesGUI = new CaloriesGUI(dailyCalories, carbohydrate, protein, fat);
        caloriesGUI.setVisible(true);

        this.dispose(); // Close the input GUI after proceeding
    }

    private String getSelectedGender() {
        if (maleRadioButton.isSelected()) {
            return maleRadioButton.getText();
        } else if (femaleRadioButton.isSelected()) {
            return femaleRadioButton.getText();
        } else if (othersRadioButton.isSelected()) {
            return othersRadioButton.getText();
        }
        return null;
    }

    private String getSelectedActivityLevel() {
        if (sedentaryRadioButton.isSelected()) {
            return sedentaryRadioButton.getText();
        } else if (lightlyActiveRadioButton.isSelected()) {
            return lightlyActiveRadioButton.getText();
        } else if (moderatelyActiveRadioButton.isSelected()) {
            return moderatelyActiveRadioButton.getText();
        } else if (veryActiveRadioButton.isSelected()) {
            return veryActiveRadioButton.getText();
        }
        return null;
    }
	

}
